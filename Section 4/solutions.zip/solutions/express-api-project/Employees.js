const employees = [

    {
        name:"Ram",
        email:"ram@gmail.com",
        age:23,
    },

    {
        name:"Shyam",
        email:"shyam@gmail.com",
        age:65,
    },

    {
        name:"Jon",
        email:"jon@yahoo.com",
        age:42,
    },

    {
        name:"Francesca",
        email:"francesca@gmail.com",
        age:30,
    },
];

module.exports = employees;
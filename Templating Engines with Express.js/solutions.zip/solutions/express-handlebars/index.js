const express = require('express');;
const app = express();
const {engine} = require('express-handlebars');

const PORT = 3030;

app.set('view engine', 'hbs');

app.engine('hbs', engine({
    layoutsDir: __dirname + '/views/layouts',
    extname: 'hbs',
    defaultLayout: 'mirror_index',
    partialsDir: __dirname + '/views/partials'
}));

// static files (import css file)
app.use(express.static('public'));

// write an api function
simulatedAPI = () => {
    return [
        {name:'Top Gun',
        colors:'even'},

        {name:'Top Gun II',
        colors:'odd'},

        {name:'Cinderella',
        colors:'even'},

        {name:'The Professional',
        colors:'odd'},

        {name:'Scary Movie II',
        colors:'even'},
    ]
};

app.get('/', (req, res) => {
    // res.send('Hello World!')});
     res.render('main', {layout: 'index', suggestedMovies: simulatedAPI()});
    //res.render('main');
});

app.listen(PORT, ()=> console.log(`App is listening to port ${PORT}`));
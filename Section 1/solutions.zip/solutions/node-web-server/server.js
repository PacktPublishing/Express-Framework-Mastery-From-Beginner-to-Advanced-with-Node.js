var http = require('http'); // 1 - Import Node.js core module

var server = http.createServer(function (req, res) {   // 2 - creating server

    //handle incomming requests here..

    if(req.url == '/')
    {
    // set response header
    res.writeHead(200, {'Content-Type': 'text/html'});

    // set response content
    res.write('<html><body><p>This is the home page</p></body></html>')
    res.end();
    }

    // add another page to our site which is the contact page 
    // leverage the if else statement

    else if(req.url == '/contact') {

            // set response header
    res.writeHead(200, {'Content-Type': 'text/html'});

    // set response content
    res.write('<html><body><p>This is the contact page</p></body></html>')
    res.end();
    }   else res.end('Invalid Request!');

});

server.listen(3000); //3 - listen for any incoming requests

// http://localhost:3000

console.log('Node.js web server at port 3000 is running..')
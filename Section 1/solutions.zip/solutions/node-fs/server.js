var fs = require('fs');

// how to append file content in node fs

/*
fs.appendFile('test.rtf', 'Hello universe!', function (err) {
    if(err)
    console.log(err);
    else
    console.log('append operation complete.');
});
*/

// how to delete files in node fs

fs.unlink('test.rtf', function() {
    console.log('write operation complete');
})

// how to read files in node fs
var data = fs.readFile('test.rtf', 
    function (err, data) {
        if (err) throw err;

    console.log(data.toString());
    })

// how to write files in node fs

/*
fs.writeFile('test.rtf', 'Hello world!', function (err) {
    if(err)
    console.log(err);
    else
    console.log('write operation complete.');
});
*/